package classes;

import java.util.Date;

public class Jogo {
    private int id;
    private int grupoId;
    private int selecao1Id;
    private int selecao2Id;
    private int golsSelecao1;
    private int golsSelecao2;

    public Jogo() {
    }

    // Getters e Setters omitidos para brevidade

    public int getId() {
        return id;
    }

    public int getGrupoId() {
        return grupoId;
    }

    public int getGolsSelecao1() {
        return golsSelecao1;
    }

    public int getGolsSelecao2() {
        return golsSelecao2;
    }

    public int getSelecao1Id() {
        return selecao1Id;
    }

    public int getSelecao2Id() {
        return selecao2Id;
    }
    @Override
    public String toString() {
        return "Jogo{" +
                "id=" + id +
                ", grupoId=" + grupoId +
                ", selecao1Id=" + selecao1Id +
                ", selecao2Id=" + selecao2Id +
                ", golsSelecao1=" + golsSelecao1 +
                ", golsSelecao2=" + golsSelecao2 +
                '}';
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setGrupoId(int grupoId) {
        this.grupoId = grupoId;
    }

    public void setSelecao1Id(int selecao1Id) {
        this.selecao1Id = selecao1Id;
    }

    public void setSelecao2Id(int selecao2Id) {
        this.selecao2Id = selecao2Id;
    }

    public void setGolsSelecao1(int golsSelecao1) {
        this.golsSelecao1 = golsSelecao1;
    }

    public void setGolsSelecao2(int golsSelecao2) {
        this.golsSelecao2 = golsSelecao2;
    }
}

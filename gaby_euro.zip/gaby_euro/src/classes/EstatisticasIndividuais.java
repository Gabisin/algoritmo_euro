package classes;

public class EstatisticasIndividuais {
    private int id;
    private int jogoId;
    private int jogadorId;
    private int passes;
    private int assistencias;
    private int remates;
    private int minutosJogados;
    private int gols;

    public EstatisticasIndividuais() {
    }

    // Getters e Setters omitidos para brevidade

    public int getId() {
        return id;
    }

    public int getAssistencias() {
        return assistencias;
    }

    public int getGols() {
        return gols;
    }

    public int getJogadorId() {
        return jogadorId;
    }

    public int getJogoId() {
        return jogoId;
    }

    public int getMinutosJogados() {
        return minutosJogados;
    }
    public int getPasses() {
        return passes;
    }
    public int getRemates() {
        return remates;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setJogoId(int jogoId) {
        this.jogoId = jogoId;
    }

    public void setJogadorId(int jogadorId) {
        this.jogadorId = jogadorId;
    }

    public void setPasses(int passes) {
        this.passes = passes;
    }

    public void setAssistencias(int assistencias) {
        this.assistencias = assistencias;
    }

    public void setRemates(int remates) {
        this.remates = remates;
    }

    public void setMinutosJogados(int minutosJogados) {
        this.minutosJogados = minutosJogados;
    }

    public void setGols(int gols) {
        this.gols = gols;
    }

    @Override
    public String toString() {
        return "EstatisticasIndividuais{" +
                "id=" + id +
                ", jogoId=" + jogoId +
                ", jogadorId=" + jogadorId +
                ", passes=" + passes +
                ", assistencias=" + assistencias +
                ", remates=" + remates +
                ", minutosJogados=" + minutosJogados +
                ", gols=" + gols +
                '}';
    }

}

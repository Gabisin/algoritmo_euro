package dao;
import classes.EstatisticasIndividuais;
import classes.Jogo;
import classes.Jogador;
import conexao.DBConnection;
import java.util.List;

public class SimuladorDeJogo {

    private final GrupoSelecaoDAO grupoSelecaoDAO;
    private final EstatisticasIndividuaisDAO estatisticasIndividuaisDAO;

    private final JogoDAO jogoDAO;

    public SimuladorDeJogo() {
        DBConnection DBConnection = new DBConnection();
        // Inicialização dos DAOs (você deve ter métodos construtores adequados)
        this.grupoSelecaoDAO = new GrupoSelecaoDAO(DBConnection); // Supondo que você tenha um construtor vazio que configure a conexão
        this.estatisticasIndividuaisDAO = new EstatisticasIndividuaisDAO(DBConnection);
        this.jogoDAO = new JogoDAO(DBConnection);
        // Supondo o mesmo para este DAO
    }

    public void simularJogo(Jogo jogo) {
        // Supondo que jogo já tenha sido iniciado e esteja em andamento

        // Simulação de gols (exemplo simples)
        int golsSelecao1 = simularGols();
        int golsSelecao2 = simularGols();

        // Atualização do resultado no jogo
        jogo.setGolsSelecao1(golsSelecao1);
        jogo.setGolsSelecao2(golsSelecao2);

        int jogoID =  jogoDAO.inserirJogo(jogo);

        jogo.setId(jogoID);

        // Atualização no banco de dados
        grupoSelecaoDAO.atualizarEstatisticasGrupo(jogo.getGrupoId(),jogo.getSelecao1Id(),jogo.getGolsSelecao1(),jogo.getGolsSelecao2()); // Atualiza dados do grupo
        grupoSelecaoDAO.atualizarEstatisticasGrupo(jogo.getGrupoId(),jogo.getSelecao2Id(),jogo.getGolsSelecao2(),jogo.getGolsSelecao1()); // Atualiza dados do grupo

        // Simulação de estatísticas individuais para cada seleção (exemplo simples)
        atualizarEstatisticasIndividuais(jogo, jogo.getSelecao1Id(), golsSelecao1);
        atualizarEstatisticasIndividuais(jogo, jogo.getSelecao2Id(), golsSelecao2);

    }

    private int simularGols() {
        // Simulação simples de gols
        return (int) (Math.random() * 5); // Gera um número aleatório de 0 a 4 gols
    }

    private void atualizarEstatisticasIndividuais(Jogo jogo, int selecaoId, int golsMarcados) {
        // Exemplo: Obter jogadores da seleção
        DBConnection DBConnection = new DBConnection();
        JogadorDAO jogadorDAO = new JogadorDAO(DBConnection);
        List<Jogador> jogadores = jogadorDAO.listarJogadoresPorSelecao(selecaoId);

        // Atualizar estatísticas individuais para cada jogador
        for (Jogador jogador : jogadores) {
            int passes = simularPasses();
            int assistencias = simularAssistencias();
            int remates = simularRemates();
            int minutosJogados = simularMinutosJogados();

            EstatisticasIndividuais estatisticasIndividuais = new EstatisticasIndividuais();
            estatisticasIndividuais.setJogoId(jogo.getId());
            estatisticasIndividuais.setAssistencias(assistencias);
            estatisticasIndividuais.setGols(golsMarcados);
            estatisticasIndividuais.setPasses(passes);
            estatisticasIndividuais.setJogadorId(jogador.getId());
            estatisticasIndividuais.setRemates(remates);
            estatisticasIndividuais.setMinutosJogados(minutosJogados);
            // Registrar estatísticas individuais
            estatisticasIndividuaisDAO.inserirEstatisticasIndividuais(estatisticasIndividuais);
        }
    }

    // Métodos simulados para estatísticas individuais (substitua com lógica adequada conforme necessário)
    private int simularPasses() {
        return (int) (Math.random() * 100); // Simulação de passes entre 0 e 99
    }

    private int simularAssistencias() {
        return (int) (Math.random() * 10); // Simulação de assistências entre 0 e 9
    }

    private int simularRemates() {
        return (int) (Math.random() * 20); // Simulação de remates entre 0 e 19
    }

    private int simularMinutosJogados() {
        return (int) (Math.random() * 90) + 1; // Simulação de minutos jogados entre 1 e 90
    }
}

package dao;
import classes.Jogador;
import classes.Selecao;
import conexao.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class JogadorDAO {
    private Connection connection;

    public JogadorDAO(DBConnection DBConnection) {
        this.connection = DBConnection.getConnection();
    }

    public void inserirJogador(Jogador jogador) {
        String query = "INSERT INTO Jogador (nome, data_nascimento, posicao, numero_camiseta, selecao_id) " +
                "VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, jogador.getNome());
            stmt.setDate(2, new java.sql.Date(jogador.getDataNascimento().getTime()));
            stmt.setString(3, jogador.getPosicao());
            stmt.setInt(4, jogador.getNumeroCamiseta());
            stmt.setInt(5, jogador.getSelecaoId());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public Jogador buscarJogadorPorId(int jogador_id) {
        Jogador jogador = null;
        String query = "SELECT * FROM Jogador WHERE id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, jogador_id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                jogador = new Jogador();
                jogador.setId(rs.getInt("id"));
                jogador.setNome(rs.getString("nome"));
                jogador.setPosicao(rs.getString("posicao"));
                jogador.setNumeroCamiseta(rs.getInt("numero_camiseta"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return jogador;
    }

    // Método para listar jogadores por seleção
    public List<Jogador> listarJogadoresPorSelecao(int selecaoId) {
        List<Jogador> jogadores = new ArrayList<>();
        String query = "SELECT * FROM Jogador WHERE selecao_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, selecaoId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Jogador jogador = new Jogador();
                jogador.setId(rs.getInt("id"));
                jogador.setNome(rs.getString("nome"));
                jogador.setDataNascimento(rs.getDate("data_nascimento"));
                jogador.setPosicao(rs.getString("posicao"));
                jogador.setNumeroCamiseta(rs.getInt("numero_camiseta"));
                jogador.setSelecaoId(rs.getInt("selecao_id"));
                jogadores.add(jogador);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return jogadores;
    }



    public List<Jogador> listarJogadores() {
        List<Jogador> jogadores = new ArrayList<>();
        String query = "SELECT * FROM Jogador";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Jogador jogador = new Jogador();
                jogador.setId(rs.getInt("id"));
                jogador.setNome(rs.getString("nome"));
                jogador.setDataNascimento(rs.getDate("data_nascimento"));
                jogador.setPosicao(rs.getString("posicao"));
                jogador.setNumeroCamiseta(rs.getInt("numero_camiseta"));
                jogador.setSelecaoId(rs.getInt("selecao_id"));
                jogadores.add(jogador);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return jogadores;
    }

    public void atualizarJogador(Jogador jogador) {
        String query = "UPDATE Jogador SET nome = ?, data_nascimento = ?, posicao = ?, " +
                "numero_camiseta = ?, selecao_id = ? WHERE id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, jogador.getNome());
            stmt.setDate(2, new java.sql.Date(jogador.getDataNascimento().getTime()));
            stmt.setString(3, jogador.getPosicao());
            stmt.setInt(4, jogador.getNumeroCamiseta());
            stmt.setInt(5, jogador.getSelecaoId());
            stmt.setInt(6, jogador.getId());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

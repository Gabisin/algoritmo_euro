package dao;
import classes.Jogo;
import conexao.DBConnection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
public class JogoDAO {
    private Connection connection;

    public JogoDAO(DBConnection DBConnection) {
        this.connection = DBConnection.getConnection();
    }
    public int inserirJogo(Jogo jogo) {
        String query = "INSERT INTO Jogo (grupo_id, selecao1_id, selecao2_id, gols_selecao1, gols_selecao2) " +
                "VALUES (?, ?, ?, ?, ?)";
        int jogoId = -1; // Inicializa com um valor padrão indicativo de erro
        try (PreparedStatement stmt = connection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setInt(1, jogo.getGrupoId());
            stmt.setInt(2, jogo.getSelecao1Id());
            stmt.setInt(3, jogo.getSelecao2Id());
            stmt.setInt(4, jogo.getGolsSelecao1());
            stmt.setInt(5, jogo.getGolsSelecao2());
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected == 1) {
                ResultSet generatedKeys = stmt.getGeneratedKeys();
                if (generatedKeys.next()) {
                    jogoId = generatedKeys.getInt(1); // Obtém o ID gerado
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return jogoId; // Retorna o ID gerado, ou -1 se ocorrer um erro
    }


    public List<Jogo> listarJogos() {
        List<Jogo> jogos = new ArrayList<>();
        String query = "SELECT * FROM Jogo";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Jogo jogo = new Jogo();
                jogo.setId(rs.getInt("id"));
                jogo.setGrupoId(rs.getInt("grupo_id"));
                jogo.setSelecao1Id(rs.getInt("selecao1_id"));
                jogo.setSelecao2Id(rs.getInt("selecao2_id"));
                jogo.setGolsSelecao1(rs.getInt("gols_selecao1"));
                jogo.setGolsSelecao2(rs.getInt("gols_selecao2"));
                jogos.add(jogo);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return jogos;
    }

    public void atualizarJogo(Jogo jogo) {
        String query = "UPDATE Jogo SET grupo_id = ?, selecao1_id = ?, selecao2_id = ?, " +
                "gols_selecao1 = ?, gols_selecao2 = ? WHERE id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, jogo.getGrupoId());
            stmt.setInt(2, jogo.getSelecao1Id());
            stmt.setInt(3, jogo.getSelecao2Id());
            stmt.setInt(4, jogo.getGolsSelecao1());
            stmt.setInt(5, jogo.getGolsSelecao2());
            stmt.setInt(6, jogo.getId());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

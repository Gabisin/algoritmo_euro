package dao;
import classes.EstatisticasIndividuais;
import conexao.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class EstatisticasIndividuaisDAO {
    private Connection connection;

    public EstatisticasIndividuaisDAO(DBConnection DBConnection) {
        this.connection = DBConnection.getConnection();
    }

    public void inserirEstatisticasIndividuais(EstatisticasIndividuais estatisticasIndividuais) {
        String query = "INSERT INTO EstatisticasIndividuais (jogo_id, jogador_id, passes, assistencias, remates, minutos_jogados, gols) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            // Check if the jogo_id exists in the jogo table before inserting
            if (checkIfJogoIdExists(estatisticasIndividuais.getJogoId())) {
                stmt.setInt(1, estatisticasIndividuais.getJogoId());
                stmt.setInt(2, estatisticasIndividuais.getJogadorId());
                stmt.setInt(3, estatisticasIndividuais.getPasses());
                stmt.setInt(4, estatisticasIndividuais.getAssistencias());
                stmt.setInt(5, estatisticasIndividuais.getRemates());
                stmt.setInt(6, estatisticasIndividuais.getMinutosJogados());
                stmt.setInt(7, estatisticasIndividuais.getGols());
                stmt.executeUpdate();
            } else {
                // Handle the case where jogo_id does not exist in the jogo table
                System.out.println("Error: jogo_id does not exist in the jogo table.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private boolean checkIfJogoIdExists(int jogoId) throws SQLException {
        String query = "SELECT id FROM jogo WHERE id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, jogoId);
            try (ResultSet rs = stmt.executeQuery()) {
                return rs.next(); // Returns true if jogo_id exists in the jogo table
            }
        }
    }
    public List<EstatisticasIndividuais> listarEstatisticasIndividuais() {
        List<EstatisticasIndividuais> estatisticasIndividuais = new ArrayList<>();
        String query = "SELECT * FROM EstatisticasIndividuais";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                EstatisticasIndividuais estatistica = new EstatisticasIndividuais();
                estatistica.setId(rs.getInt("id"));
                estatistica.setJogoId(rs.getInt("jogo_id"));
                estatistica.setJogadorId(rs.getInt("jogador_id"));
                estatistica.setPasses(rs.getInt("passes"));
                estatistica.setAssistencias(rs.getInt("assistencias"));
                estatistica.setRemates(rs.getInt("remates"));
                estatistica.setMinutosJogados(rs.getInt("minutos_jogados"));
                estatistica.setGols(rs.getInt("gols"));
                estatisticasIndividuais.add(estatistica);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return estatisticasIndividuais;
    }
    public void inserirOuAtualizarEstatisticasIndividuais(EstatisticasIndividuais estatisticasIndividuais) {
        // Verifica se já existe uma entrada para este jogador nesta partida
        String query = "SELECT * FROM EstatisticasIndividuais WHERE jogo_id = ? AND jogador_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, estatisticasIndividuais.getJogoId());
            stmt.setInt(2, estatisticasIndividuais.getJogadorId());
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                // Se já existe, atualiza as estatísticas individuais
                String updateQuery = "UPDATE EstatisticasIndividuais SET passes = ?, assistencias = ?, remates = ?, " +
                        "minutos_jogados = ?, gols = ? WHERE jogo_id = ? AND jogador_id = ?";
                try (PreparedStatement updateStmt = connection.prepareStatement(updateQuery)) {
                    updateStmt.setInt(1, estatisticasIndividuais.getPasses());
                    updateStmt.setInt(2, estatisticasIndividuais.getAssistencias());
                    updateStmt.setInt(3, estatisticasIndividuais.getRemates());
                    updateStmt.setInt(4, estatisticasIndividuais.getMinutosJogados());
                    updateStmt.setInt(5, estatisticasIndividuais.getGols());
                    updateStmt.setInt(6, estatisticasIndividuais.getJogoId());
                    updateStmt.setInt(7, estatisticasIndividuais.getJogadorId());
                    updateStmt.executeUpdate();
                }
            } else {
                // Caso contrário, insere uma nova entrada para o jogador nesta partida
                String insertQuery = "INSERT INTO EstatisticasIndividuais (jogo_id, jogador_id, passes, assistencias, remates, minutos_jogados, gols) " +
                        "VALUES (?, ?, ?, ?, ?, ?, ?)";
                try (PreparedStatement insertStmt = connection.prepareStatement(insertQuery)) {
                    insertStmt.setInt(1, estatisticasIndividuais.getJogoId());
                    insertStmt.setInt(2, estatisticasIndividuais.getJogadorId());
                    insertStmt.setInt(3, estatisticasIndividuais.getPasses());
                    insertStmt.setInt(4, estatisticasIndividuais.getAssistencias());
                    insertStmt.setInt(5, estatisticasIndividuais.getRemates());
                    insertStmt.setInt(6, estatisticasIndividuais.getMinutosJogados());
                    insertStmt.setInt(7, estatisticasIndividuais.getGols());
                    insertStmt.executeUpdate();
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public void atualizarEstatisticasIndividuais(EstatisticasIndividuais estatisticasIndividuais) {
        String query = "UPDATE EstatisticasIndividuais SET jogo_id = ?, jogador_id = ?, passes = ?, " +
                "assistencias = ?, remates = ?, minutos_jogados = ?, gols = ? WHERE id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, estatisticasIndividuais.getJogoId());
            stmt.setInt(2, estatisticasIndividuais.getJogadorId());
            stmt.setInt(3, estatisticasIndividuais.getPasses());
            stmt.setInt(4, estatisticasIndividuais.getAssistencias());
            stmt.setInt(5, estatisticasIndividuais.getRemates());
            stmt.setInt(6, estatisticasIndividuais.getMinutosJogados());
            stmt.setInt(7, estatisticasIndividuais.getGols());
            stmt.setInt(8, estatisticasIndividuais.getId());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public List<EstatisticasIndividuais> listarMelhoresMarcadores() {
        List<EstatisticasIndividuais> melhoresMarcadores = new ArrayList<>();
        String query = "SELECT jogador_id, SUM(gols) AS total_gols FROM EstatisticasIndividuais GROUP BY jogador_id ORDER BY total_gols DESC LIMIT ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, 10);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                EstatisticasIndividuais estatistica = new EstatisticasIndividuais();
                estatistica.setJogadorId(rs.getInt("jogador_id"));
                estatistica.setGols(rs.getInt("total_gols"));
                melhoresMarcadores.add(estatistica);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return melhoresMarcadores;
    }

    public List<EstatisticasIndividuais> listarMelhoresAssistentes() {
        List<EstatisticasIndividuais> melhoresAssistentes = new ArrayList<>();
        String query = "SELECT jogador_id, SUM(assistencias) AS total_assistencias FROM EstatisticasIndividuais GROUP BY jogador_id ORDER BY total_assistencias DESC LIMIT ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, 10);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                EstatisticasIndividuais estatistica = new EstatisticasIndividuais();
                estatistica.setJogadorId(rs.getInt("jogador_id"));
                estatistica.setAssistencias(rs.getInt("total_assistencias"));
                melhoresAssistentes.add(estatistica);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return melhoresAssistentes;
    }

}


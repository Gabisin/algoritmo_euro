import classes.*;
import conexao.DBConnection;
import dao.*;
import java.util.List;
import java.util.Scanner;

public class Main_Antigo {
    private static final Scanner scanner = new Scanner(System.in);
    private static final DBConnection DB_CONNECTION = new DBConnection();
    private static final PaisDAO paisDAO = new PaisDAO(DB_CONNECTION);
    private static final CidadeDAO cidadeDAO = new CidadeDAO(DB_CONNECTION);
    private static final EstadioDAO estadioDAO = new EstadioDAO(DB_CONNECTION);
    private static final SelecaoDAO selecaoDAO = new SelecaoDAO(DB_CONNECTION);
    private static final JogadorDAO jogadorDAO = new JogadorDAO(DB_CONNECTION);
    private static final GrupoDAO grupoDAO = new GrupoDAO(DB_CONNECTION);
    private static final GrupoSelecaoDAO grupoSeleccaoDAO = new GrupoSelecaoDAO(DB_CONNECTION);
    private static final JogoDAO jogoDAO = new JogoDAO(DB_CONNECTION);
    private static final EstatisticasIndividuaisDAO estatisticasIndividuaisDAO = new EstatisticasIndividuaisDAO(DB_CONNECTION);
    private static  final  SimuladorDeJogo simuladorDeJogo = new SimuladorDeJogo();

    public static void main(String[] args) {
        boolean sair = false;
        int opcao;

        while (!sair) {
            exibirMenuPrincipal();
            opcao = scanner.nextInt();
            scanner.nextLine(); // Limpar o buffer após a leitura do inteiro

            switch (opcao) {
                case 1:
                    cadastrarPais();
                    break;
                case 2:
                    cadastrarCidade();
                    break;
                case 3:
                    cadastrarEstadio();
                    break;
                case 4:
                    cadastrarSelecao();
                    break;
                case 5:
                    cadastrarJogador();
                    break;
                case 6:
                    cadastrarGrupo();
                    break;
                case 7:
                    realizarPartida();
                    break;
                case 8:
                    listarPais();
                    break;
                case 9:
                    listarCidade();
                    break;
                case 10:
                    listarEstadio();
                    break;
                case 11:
                    listarSelecoes();
                    break;
                case 12:
                    listarJogadores();
                    break;
                case 13:
                    grupoSeleccaoDAO.listarClassificacaoGrupos();
                    break;
                case 14:
                    listarPartidas();
                    break;
                case 15:
                    listarMelhoresMarcadores();
                    break;
                case 16:
                    listarMelhoresAssistentes();
                    break;
                case 17:
                    distribuirSelecoesGrupo();
                    break;
                case 18:
                    sair = true;
                    break;
                default:
                    System.out.println("Opção inválida. Por favor, escolha uma opção válida.");
            }
        }

        System.out.println("Encerrando o programa...");
    }

    private static void exibirMenuPrincipal() {
        System.out.println("\n=== Menu Principal ===");
        System.out.println("1. Cadastrar Pais");
        System.out.println("2. Cadastrar Cidade");
        System.out.println("3. Cadastrar Estadio");
        System.out.println("4. Cadastrar Seleção");
        System.out.println("5. Cadastrar Jogador");
        System.out.println("6. Cadastrar Grupo");
        System.out.println("7. Realizar Partida");
        System.out.println("8. Listar Pais");
        System.out.println("9. Listar Cidade");
        System.out.println("10. Listar Estadio");
        System.out.println("11. Listar Seleções");
        System.out.println("12. Listar Jogadores");
        System.out.println("13. Listar Grupos");
        System.out.println("14. Listar Partidas");
        System.out.println("15. Listar Melhores Marcadores");
        System.out.println("16. Listar Melhores Assistentes");
        System.out.println("17. Distribuir selecoes em Grupos");
        System.out.println("18. Sair");
        System.out.print("Escolha uma opção: ");
    }

    private static void cadastrarPais() {
        System.out.println("\n=== Cadastrar Pais ===");
        System.out.print("Nome do Pais: ");
        String nomeSelecao = scanner.nextLine();

        Pais pais = new Pais();
        pais.setNome(nomeSelecao);
        paisDAO.inserirPais(pais);
        System.out.println("Pais cadastrada com sucesso!");
    }
    private static void cadastrarCidade() {
        System.out.println("\n=== Cadastrar Cidade ===");
        System.out.print("Nome da Cidade: ");
        String nomeCidade = scanner.nextLine();
        System.out.print("Pais ID: ");
        int paisID = scanner.nextInt();
        Cidade cidade = new Cidade();
        cidade.setNome(nomeCidade);
        Pais getPaisID = paisDAO.buscarCidadePorId(paisID);
        if(getPaisID != null){
            cidadeDAO.inserirCidade(cidade);
            System.out.println("Cidade cadastrada com sucesso!");
        }else{
            System.out.println("ID não foi encontrado.");
        }
    }

    private static void cadastrarEstadio() {
        System.out.println("\n=== Cadastrar Estadio ===");
        System.out.print("Nome do Estadio: ");
        String nomeEstadio = scanner.nextLine();
        System.out.print("Cidade ID: ");
        int cidadeID = scanner.nextInt();
        Estadio estadio = new Estadio();
        estadio.setNome(nomeEstadio);
        Cidade getCidadeID = cidadeDAO.buscarCidadePorId(cidadeID);
        if(getCidadeID != null){
            estadioDAO.inserirEstadio(estadio);
            System.out.println("Estadio cadastrado com sucesso!");
        }else{
            System.out.println("ID não foi encontrado.");
        }
    }

    private static void cadastrarSelecao() {
        System.out.println("\n=== Cadastrar Seleção ===");
        System.out.print("Nome da Seleção: ");
        String nomeSelecao = scanner.nextLine();
        System.out.print("ID do País: ");
        int paisId = scanner.nextInt();
        scanner.nextLine(); // Limpar o buffer após a leitura do inteiro

        Selecao selecao = new Selecao();
        selecao.setNome(nomeSelecao);
        selecao.setPaisId(paisId);

        selecaoDAO.inserirSelecao(selecao);
        System.out.println("Seleção cadastrada com sucesso!");
    }

    private static void cadastrarJogador() {
        System.out.println("\n=== Cadastrar Jogador ===");
        System.out.print("Nome do Jogador: ");
        String nomeJogador = scanner.nextLine();
        System.out.print("Data de Nascimento (AAAA-MM-DD): ");
        String dataNascimentoStr = scanner.nextLine();
        System.out.print("Posição do Jogador: ");
        String posicaoJogador = scanner.nextLine();
        System.out.print("Número da Camiseta: ");
        int numeroCamiseta = scanner.nextInt();
        System.out.print("ID da Seleção: ");
        int selecaoId = scanner.nextInt();
        scanner.nextLine(); // Limpar o buffer após a leitura do inteiro

        Jogador jogador = new Jogador();
        jogador.setNome(nomeJogador);
        jogador.setDataNascimento(java.sql.Date.valueOf(dataNascimentoStr));
        jogador.setPosicao(posicaoJogador);
        jogador.setNumeroCamiseta(numeroCamiseta);
        jogador.setSelecaoId(selecaoId);

        jogadorDAO.inserirJogador(jogador);
        System.out.println("Jogador cadastrado com sucesso!");
    }

    private static void cadastrarGrupo() {
        System.out.println("\n=== Cadastrar Grupo ===");
        System.out.print("Nome do Grupo (A, B, C, etc.): ");
        String nomeGrupo = scanner.nextLine();
        Grupo grupo = new Grupo();
        grupo.setNome(nomeGrupo);
        grupoDAO.inserirGrupo(grupo);
        System.out.println("Grupo cadastrado com sucesso!");
    }

    private static void realizarPartida() {
        System.out.println("\n=== Realizar Partida ===");
        // Exibir grupos disponíveis para escolher o grupo da partida
        grupoSeleccaoDAO.listarClassificacaoGrupos();
        System.out.print("Escolha o ID do Grupo da Partida: ");
        int grupoId = scanner.nextInt();
        scanner.nextLine(); // Limpar o buffer após a leitura do inteiro
        // Exibir seleções disponíveis para escolher a seleção 1 da partida
        Grupo grupo = grupoDAO.buscarGrupoPorId(grupoId);
        if(grupo != null){
            listarSelecoesGrupo(grupoId);
            System.out.print("Escolha o ID da Seleção Casa: ");
            int selecao1_id = scanner.nextInt();
            scanner.nextLine(); // Limpar o buffer após a leitura do inteiro
            listarSelecoes();
            System.out.print("Escolha o ID da Seleção Fora: ");
            int selecao2_id = scanner.nextInt();
            scanner.nextLine(); // Limpar o buffer após a leitura do inteiro
            Selecao selecao_casa = selecaoDAO.buscarSelecaoPorId(selecao1_id);
            Selecao selecao_fora = selecaoDAO.buscarSelecaoPorId(selecao2_id);
            if(selecao_casa != null){
                if(selecao_fora != null){
                    if(selecaoDAO.selecaoPertenceAoGrupo(grupoId,selecao1_id)){
                        if(selecaoDAO.selecaoPertenceAoGrupo(grupoId,selecao2_id)){
                            Jogo jogo = new Jogo();
                            jogo.setSelecao1Id(selecao_casa.getId());
                            jogo.setSelecao2Id(selecao_fora.getId());
                            jogo.setGrupoId(grupoId);
                            simuladorDeJogo.simularJogo(jogo);
                            System.out.println("Partida realizada com sucesso entre " + selecao_casa.getNome() + " X " + selecao_fora.getNome());
                        }
                    }

                }else{
                    System.out.println("Equipe nao encontrada");
                }
            }else{
                System.out.println("Equipe nao encontrada");
            }
        }else{
            System.out.println("Grupo nao encontrado.");
        }
    }
    private static void listarSelecoes() {
        System.out.println("\n=== Lista de Seleções ===");
        List<Selecao> selecoes = selecaoDAO.listarSelecoes();
        for (Selecao selecao : selecoes) {
            System.out.println(selecao.getId() + ". " + selecao.getNome());
        }
    }

    private static void listarSelecoesGrupo(int grupo_id) {
        System.out.println("\n=== Lista de Seleções ===");
        List<Selecao> selecoes = selecaoDAO.listarSelecoesPorGrupo(grupo_id);
        for (Selecao selecao : selecoes) {
            System.out.println(selecao.getId() + ". " + selecao.getNome());
        }
    }

    private static void listarPais() {
        System.out.println("\n=== Lista de Pais ===");
        List<Pais> paises = paisDAO.listarPaises();
        for (Pais pais : paises) {
            System.out.println(pais.getId() + ". " + pais.getNome());
        }
    }

    private static void listarCidade() {
        System.out.println("\n=== Lista de Cidades ===");
        List<Cidade> cidades = cidadeDAO.listarCidades();
        for (Cidade cidade : cidades) {
            System.out.println(cidade.getId() + ". " + cidade.getNome());
        }
    }
    private static void listarEstadio() {
        System.out.println("\n=== Lista de Estadios ===");
        List<Estadio> estadios = estadioDAO.listarEstadios();
        for (Estadio estadio : estadios) {
            System.out.println(estadio.getId() + ". " + estadio.getNome());
        }
    }

    private static void listarJogadores() {
        System.out.println("\n=== Lista de Jogadores ===");
        List<Jogador> jogadores = jogadorDAO.listarJogadores();
        for (Jogador jogador : jogadores) {
            System.out.println(jogador.getId() + ". " + jogador.getNome() + " - Posição: " + jogador.getPosicao());
        }
    }
    private static void listarPartidas() {
        System.out.println("\n=== Lista de Partidas ===");
        List<Jogo> partidas = jogoDAO.listarJogos();
        for (Jogo jogo : partidas) {
            Selecao selecao1 = selecaoDAO.buscarSelecaoPorId(jogo.getSelecao1Id());
            Selecao selecao2 = selecaoDAO.buscarSelecaoPorId(jogo.getSelecao2Id());
            System.out.println("ID: " + jogo.getId() + ", Grupo: " + jogo.getGrupoId() +
                    ", " + selecao1.getNome() + " " + jogo.getGolsSelecao1() + " x " +
                    jogo.getGolsSelecao2() + " " + selecao2.getNome());
        }
    }

    private static void distribuirSelecoesGrupo(){
        System.out.println("Digite o nome do grupo: ");
        String nomeGrupo  = scanner.nextLine();
        Grupo grupo = grupoDAO.buscarGrupoPorNome(nomeGrupo);
        if(grupo != null){
            int  totalGrupos = grupoDAO.contarNumeroGrupos();
            List<Integer> selecoesID = selecaoDAO.listarSelecoesID();
            grupoSeleccaoDAO.distribuirSelecoesNosGrupos(selecoesID,totalGrupos);
            System.out.println("Foi feita a distribuicao das equpes no grupo : " + nomeGrupo);
        }else{
            System.out.println("Grupo não encontrado");
        }
    }

    private static void listarMelhoresMarcadores() {
        System.out.println("\n=== Lista de Melhores Marcadores ===");
        List<EstatisticasIndividuais> melhoresMarcadores = estatisticasIndividuaisDAO.listarMelhoresMarcadores();
        for (EstatisticasIndividuais estatisticasIndividuais : melhoresMarcadores) {
            Jogador jogador = jogadorDAO.buscarJogadorPorId(estatisticasIndividuais.getJogadorId());
            System.out.println("Jogador: " + jogador.getNome() + "  -  " + jogador.getNumeroCamiseta() +
                    " golos:  " + estatisticasIndividuais.getGols());
        }
    }
    private static void listarMelhoresAssistentes() {
        System.out.println("\n=== Lista de Melhores Assistentes ===");
        List<EstatisticasIndividuais> melhoresMarcadores = estatisticasIndividuaisDAO.listarMelhoresAssistentes();
        for (EstatisticasIndividuais estatisticasIndividuais : melhoresMarcadores) {
            Jogador jogador = jogadorDAO.buscarJogadorPorId(estatisticasIndividuais.getJogadorId());
            System.out.println("Jogador: " + jogador.getNome() + "  -  " + jogador.getNumeroCamiseta() +
                    " assistencias:  " + estatisticasIndividuais.getAssistencias());
        }
    }
}